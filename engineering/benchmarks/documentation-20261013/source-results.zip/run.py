"""串行运行历史合成基准；新输出、空缓存和单线程均由入口保证。"""

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
THREADS = (
    "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
    "NUMBA_NUM_THREADS", "RAYON_NUM_THREADS",
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("suite", choices=("daily", "batch", "grid", "matrix"))
    parser.add_argument("--engine", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--native", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--scenario", default="daily_sparse_targets")
    return parser.parse_args()


def command(args):
    daily = ROOT / "sources" / "daily"
    if args.suite == "matrix":
        extra = ["--scenario", args.scenario]
        if args.smoke:
            extra += ["--smoke", "--seconds", "0", "--repeats", "1"]
        script = ROOT / "sources" / "matrix" / "matrix.py"
    elif args.suite == "daily":
        script = daily / "benchmark.py"
        extra = ["--bars", "40" if args.smoke else "2520", "--assets", "2" if args.smoke else "100"]
        if args.smoke:
            extra += ["--min-seconds", "0", "--repeats", "1"]
    elif args.suite == "batch":
        script = daily / "batch.py"
        extra = []
    else:
        script = daily / "heavy.py"
        extra = ["--count", "1"] if args.smoke else []
    return [sys.executable, str(script), "--engine", args.engine,
            "--output", str(args.output.resolve()), *extra]


def environment(args):
    env = os.environ.copy()
    env.update({name: "1" for name in THREADS})
    env.pop("PYTHONPATH", None)
    env.pop("MATRIX_NATIVE_REQUIRED", None)
    env.pop("MATRIX_EXPECT_INSTALLED_ROOT", None)
    env["DORIBT_NATIVE_RECORDS"] = "required" if args.native else "off"
    if args.source:
        env["PYTHONPATH"] = str(args.source.resolve())
    cache = args.output.with_suffix(".numba-cache").resolve()
    cache.mkdir(exist_ok=False)
    env["NUMBA_CACHE_DIR"] = str(cache)
    if args.engine == "dori" or args.engine.startswith("doribt"):
        probe = (
            "import json,doribt;from pathlib import Path;"
            "from doribt.runtime import native_records;"
            "print(json.dumps([doribt.__version__,str(Path(doribt.__file__).resolve().parent.parent),"
            "native_records.available()]))"
        )
        version, root, native = json.loads(subprocess.check_output(
            [sys.executable, "-c", probe], env=env, text=True))
        if version != "0.6.0":
            raise RuntimeError("复现归档要求精确测试包版本；参见 artifact-provenance.json")
        if bool(native) != args.native:
            raise RuntimeError("实际原生扩展状态与所选纯包／原生配置不同")
        env["MATRIX_EXPECT_INSTALLED_ROOT"] = root
        if args.native:
            env["MATRIX_NATIVE_REQUIRED"] = "1"
    return env


def main():
    args = parse_args()
    if args.output.exists():
        raise FileExistsError("请换新输出名，保留已有结果")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    env = environment(args)
    with args.output.with_suffix(".log").open("w") as log:
        subprocess.run(command(args), env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    result = json.loads(args.output.read_text())
    result["portable_reproduction"] = {
        "fresh_cache_per_process": True,
        "thread_limits": {name: env[name] for name in THREADS},
        "smoke_only": args.smoke,
        "native_requested": args.native,
        "cache_note": "原矩阵按批次清空缓存；此便携入口每个进程清空，首轮不可直接横比。",
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print("完成：", args.output)


if __name__ == "__main__":
    main()
