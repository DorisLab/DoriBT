"""计时结束后核验最后热轮的经济输出及归档完整审计字段。"""

import argparse
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "sources" / "matrix"))
from matrix_extra_models import constraints_oracle, stateful_oracle
from matrix_workloads import (
    SCENARIOS, make_inputs, independent_cash_oracle, independent_execution_oracle,
    independent_plain_oracle, independent_weight_oracle,
)


def oracle(scenario, inputs):
    if scenario.feature == "plain":
        return independent_plain_oracle(inputs)
    if scenario.feature in ("fees", "partial"):
        return independent_execution_oracle(scenario, inputs)
    if scenario.feature == "cash":
        return independent_cash_oracle(inputs)
    if scenario.feature.startswith("weight_"):
        return independent_weight_oracle(scenario, inputs)
    if scenario.feature == "constraints":
        return constraints_oracle(inputs)
    if scenario.feature == "stateful":
        return stateful_oracle(inputs)
    return None


def check_audit(actual, archived):
    for name, fields in archived["public_fields"].items():
        if name != "run_info":
            assert actual["public_fields"][name] == fields, name
    print("完整公开审计字段与归档一致；run_info 来源元数据单独保留")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result", type=Path)
    parser.add_argument("--kind", choices=("pure", "native", "vectorbt", "rust-alternative", "numba-alternative"), required=True)
    args = parser.parse_args()
    result = json.loads(args.result.read_text())
    scenario = next(s for s in SCENARIOS if s.name == result["scenario"]["name"])
    expected = oracle(scenario, make_inputs(scenario, result["smoke"]))
    if expected is not None:
        with np.load(args.result.with_suffix(".npz")) as actual:
            for name, values in expected.items():
                np.testing.assert_allclose(actual[name], values, rtol=0, atol=1e-6, err_msg=name)
        print("最后热轮经济输出通过独立整数参考")
    elif result["smoke"]:
        raise RuntimeError("公司行动没有独立外部模型；缩小输入不可对照完整归档")
    if result["engine"] == "dori" and not result["smoke"]:
        archived = json.loads((ROOT / "recorded" / "matrix" / args.kind / (scenario.name + ".json")).read_text())
        assert result["workload_sha256"] == archived["workload_sha256"]
        check_audit(result, archived)


if __name__ == "__main__":
    main()
