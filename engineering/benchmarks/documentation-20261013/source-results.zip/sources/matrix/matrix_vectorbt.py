"""VectorBT 1.1.2 公共 API 适配；约束不等价时拒绝给出比值。"""
import importlib.metadata
import os
import numpy as np

def prepare_vectorbt(s,x):
    import vectorbt as vbt
    if importlib.metadata.version('vectorbt')!='1.1.2' or importlib.metadata.version('vectorbt-rust')!='1.1.2':
        raise RuntimeError('Matrix requires vectorbt and vectorbt-rust 1.1.2')
    if s.vbt is None and s.feature not in ('cash','constraints','stateful'): raise ValueError('No independently validated equivalent VectorBT model for this row')
    close=x['close']/100; price=x['price']/100
    common=dict(init_cash=x['cash'],cash_sharing=True,group_by=True,freq='5min' if s.minute else '1D')
    if s.callback and s.feature=='plain' and os.environ.get('MATRIX_TARGET_CALLBACK_MODE')!='rust':
        from matrix_extra_models import prepare_target_callback
        return prepare_target_callback(x,common)
    if s.feature in ('constraints','stateful'):
        from matrix_extra_models import prepare_constraints,prepare_stateful
        return prepare_constraints(x,common) if s.feature=='constraints' else prepare_stateful(x,common,os.environ.get('MATRIX_STATEFUL_NUMBA')=='1')
    if s.vbt=='rust':
        targets=x['targets']; sizes=np.full(targets.shape,np.nan)
        sizes[1:]=np.where(np.vstack([np.ones((1,targets.shape[1]),bool),np.diff(targets[:-1],axis=0)!=0]),targets[:-1],np.nan)
        def run():
            return vbt.Portfolio.from_orders(close,size=sizes,size_type='targetamount',price=price,
                fees=0,slippage=0,direction='longonly',engine='rust',**common)
        return run
    from numba import njit
    if s.feature.startswith('weight_'): return prepare_weights(s,x,close,price,common)
    # 此 Numba 策略是独立、显式实现的同一目标规则，不编译用户 Python 回调。
    @njit
    def reserve(c,targets,cl,enabled):
        budgets=np.zeros(c.group_len,np.int64)
        available=int(np.rint(c.last_cash[c.group]*100))
        if enabled and c.i>0:
            for j in range(c.from_col,c.to_col):
                qty=max(0,targets[c.i-1,j]-c.last_position[j])
                budgets[j-c.from_col]=min(available,int(qty)*int(np.rint(cl[c.i-1,j]*100)))
                available-=budgets[j-c.from_col]
        return budgets,np.array([available])
    @njit
    def order_func(c,budgets,free,targets,op,vol,fee_on,reservation_on):
        if c.i==0: return vbt.portfolio.nb.order_nb(size=np.nan)
        requested=targets[c.i-1,c.col]-c.position_now
        if requested==0: return vbt.portfolio.nb.order_nb(size=np.nan)
        qty=min(abs(requested),vol[c.i,c.col])
        fixed=0.0
        if fee_on:
            notional_cents=int(qty)*int(np.rint(op[c.i,c.col]*100))
            fixed=max(500,(notional_cents*3+5000)//10000)/100
        if requested>0:
            if reservation_on:
                qty=min(qty,(budgets[c.col-c.from_col]+free[0])//int(np.rint(op[c.i,c.col]*100)))
            else: qty=min(qty,np.floor((c.cash_now-fixed)/op[c.i,c.col]+1e-10))
        if qty<=0: return vbt.portfolio.nb.order_nb(size=np.nan)
        if reservation_on:
            spend=int(qty)*int(np.rint(op[c.i,c.col]*100))
            if requested<0: free[0]+=spend
            elif qty==requested: free[0]+=budgets[c.col-c.from_col]-spend
            else: free[0]=max(0,free[0]-max(0,spend-budgets[c.col-c.from_col]))
        return vbt.portfolio.nb.order_nb(size=qty if requested>0 else -qty,price=op[c.i,c.col],
            direction=0,fees=0,fixed_fees=fixed,allow_partial=False)
    def run():
        return vbt.Portfolio.from_order_func(close,order_func,x['targets'],price,x['volume'],s.feature=='fees',s.feature=='cash',
                pre_segment_func_nb=reserve,pre_segment_args=(x['targets'],close,s.feature=='cash'),**common)
    return run

def economic_vectorbt(r):
    fills=np.array([(int(f['idx']),int(f['col']),float(f['size'])*(1 if f['side']==0 else -1),
                     float(f['price']),float(f['fees'])) for f in r.orders.records_arr]).reshape(-1,5)
    # from_orders 按列存记录；经济验证使用时间、证券排序，执行优先级另由现金路径验证。
    if len(fills): fills=fills[np.lexsort((fills[:,1],fills[:,0]))]
    return dict(cash=np.asarray(r.cash()).reshape(-1),holdings=np.asarray(r.assets()),
                equity=np.asarray(r.value()).reshape(-1),fills=fills)


def prepare_weights(s,x,close,price,common):
    import vectorbt as vbt
    from numba import njit
    @njit
    def resize(c,desired,signals,cl,op,execution,rebalance):
        if c.i>0:
            changed=c.i==1
            if not changed:
                for j in range(c.from_col,c.to_col):
                    if signals[c.i-1,j]!=signals[c.i-2,j]: changed=True
            if changed or rebalance:
                value=int(np.rint(c.last_cash[c.group]*100))
                for j in range(c.from_col,c.to_col):
                    px=int(np.rint((op[c.i,j] if execution else cl[c.i-1,j])*100))
                    value+=int(np.rint(c.last_position[j]))*px
                ppm=800000//c.group_len
                for j in range(c.from_col,c.to_col):
                    px=int(np.rint((op[c.i,j] if execution else cl[c.i-1,j])*100))
                    desired[j]=(value*ppm)//(px*1000000) if signals[c.i-1,j]>0 else 0
        return (desired,)
    @njit
    def order(c,desired,op):
        if c.i==0: return vbt.portfolio.nb.order_nb(size=np.nan)
        qty=desired[c.col]-c.position_now
        return vbt.portfolio.nb.order_nb(size=qty if qty else np.nan,price=op[c.i,c.col],direction=0,allow_partial=False)
    def run():
        return vbt.Portfolio.from_order_func(close,order,price,pre_segment_func_nb=resize,
            pre_segment_args=(np.zeros(price.shape[1],np.int64),x['targets'],close,price,'execution' in s.feature,s.feature.endswith('rebalance')),**common)
    return run
