"""原生可用性强制检查；实际路由诊断单独执行，不计入任何性能样本。"""
import hashlib, importlib, os, sys
from pathlib import Path

def verify_native():
    if os.environ.get('DORIBT_NATIVE_RECORDS')!='required':
        raise RuntimeError('Native benchmark requires DORIBT_NATIVE_RECORDS=required')
    runtime=importlib.import_module('doribt.runtime.native_records')
    extension=importlib.import_module('doribt._native_records')
    if not runtime.available() or extension.API_VERSION!=1:
        raise RuntimeError('Required native materializer is unavailable or incompatible')
    binary=Path(extension.__file__).resolve()
    root=Path(os.environ['MATRIX_EXPECT_INSTALLED_ROOT']).resolve()
    if not binary.is_relative_to(root):raise RuntimeError('Native binary was not loaded from installed wheel')
    return {'required_mode':True,'available':True,'api_version':extension.API_VERSION,
            'module_path':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}

def diagnose_route(runner,scenario):
    calls={}
    def profile(frame,event,arg):
        if event=='c_call' and getattr(arg,'__module__',None)=='doribt._native_records':
            name=getattr(arg,'__name__','unknown');calls[name]=calls.get(name,0)+1
    previous=sys.getprofile()
    try:
        sys.setprofile(profile)
        result=runner()
    finally:sys.setprofile(previous)
    expected=sum(bool(getattr(result,k)) for k in ('orders','intents','fills','tax_lots'))
    required=scenario in ('minute_dense_targets','minute_t1_limits_status','minute_weights_execution_rebalance')
    if (required or calls) and calls.get('bulk_columns',0)!=expected:
        raise RuntimeError(f'Expected {expected} nonempty native batches in {scenario}, observed {calls}')
    return {'nonempty_audit_collections':expected,'untimed_c_calls':calls,'instrumentation':'sys.setprofile only on a separate post-timing run','native_route_used':bool(calls),'scope':'Native record materialization applies only to eligible compiled schedules; ordinary callback and legacy paths may legitimately retain existing record construction'}
