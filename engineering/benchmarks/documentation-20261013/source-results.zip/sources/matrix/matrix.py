"""隔离进程执行矩阵：导入、准备、首轮、热执行和结果物化分开计时。"""
import argparse, dataclasses, hashlib, importlib.metadata, json, os, resource, sys, time
from collections.abc import Mapping
from pathlib import Path

START=time.perf_counter()
import numpy as np
from matrix_workloads import SCENARIOS, make_inputs, prepare_dori, independent_plain_oracle, independent_execution_oracle, independent_cash_oracle, independent_weight_oracle
IMPORT_BASE=time.perf_counter()-START

def norm(v):
    if dataclasses.is_dataclass(v): return {f.name:norm(getattr(v,f.name)) for f in dataclasses.fields(v)}
    if isinstance(v,np.ndarray): return {'shape':v.shape,'dtype':str(v.dtype),'readonly':not v.flags.writeable,'sha256':hashlib.sha256(v.tobytes()).hexdigest()}
    if isinstance(v,Mapping): return {str(k):norm(w) for k,w in v.items()}
    if isinstance(v,(list,tuple)): return [norm(w) for w in v]
    if isinstance(v,np.generic): return v.item()
    return v

def public_fields(result):
    fields={}
    for f in dataclasses.fields(result):
        value=norm(getattr(result,f.name))
        # 版本、源码路径和策略 provenance 单独保存，不冒充经济差异。
        raw=json.dumps(value,sort_keys=True,default=str,separators=(',',':')).encode()
        fields[f.name]={'sha256':hashlib.sha256(raw).hexdigest()}
        if isinstance(value,dict) and 'shape' in value: fields[f.name].update(value)
    return fields

def economic_dori(r,data):
    tm={t:i for i,t in enumerate(data.timeline)}; sy={s:j for j,s in enumerate(data.symbols)}
    fills=np.array([(tm[f.timestamp or f.session],sy[f.symbol],f.quantity,f.price_units/10000,
                      (f.commission_units+f.stamp_duty_units+f.transfer_fee_units)/10000) for f in r.fills]).reshape(-1,5)
    if len(fills): fills=fills[np.lexsort((fills[:,1],fills[:,0]))]
    return dict(cash=r.cash,holdings=r.holdings,equity=r.equity,fills=fills)

def save_economic(path,values): np.savez_compressed(path,**values)

def main():
    p=argparse.ArgumentParser();p.add_argument('--scenario',required=True);p.add_argument('--engine',choices=['dori','vbt'],default='dori')
    p.add_argument('--output',required=True);p.add_argument('--smoke',action='store_true');p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--reference');p.add_argument('--profile')
    args=p.parse_args(); s=next(s for s in SCENARIOS if s.name==args.scenario)
    start=time.perf_counter()
    if args.engine=='dori':
        import doribt
        expected_root=os.environ.get('MATRIX_EXPECT_INSTALLED_ROOT')
        if expected_root and not Path(doribt.__file__).resolve().is_relative_to(Path(expected_root).resolve()):
            raise RuntimeError('DoriBT import did not resolve to the required installed wheel')
        if os.environ.get('MATRIX_NATIVE_REQUIRED')=='1':
            from matrix_native_evidence import verify_native
            native_evidence=verify_native()
        else: native_evidence=None
    else: import vectorbt
    imported=time.perf_counter()-start
    start=time.perf_counter(); x=make_inputs(s,args.smoke); generated=time.perf_counter()-start
    start=time.perf_counter()
    if args.engine=='dori': runner,data=prepare_dori(s,x)
    else:
        from matrix_vectorbt import prepare_vectorbt
        runner=prepare_vectorbt(s,x);data=None
    preparation=time.perf_counter()-start
    start=time.perf_counter();result=runner();first=time.perf_counter()-start
    from matrix_vectorbt import economic_vectorbt
    start=time.perf_counter();econ=economic_dori(result,data) if data else economic_vectorbt(result);materialization=time.perf_counter()-start
    if s.feature=='plain':
        for key,expected in independent_plain_oracle(x).items():
            np.testing.assert_allclose(econ[key],expected,atol=1e-6,rtol=0,err_msg='independent oracle '+key)
    if s.feature in ('fees','partial'):
        for key,expected in independent_execution_oracle(s,x).items():
            np.testing.assert_allclose(econ[key],expected,atol=1e-6,rtol=0,err_msg='independent execution oracle '+key)
    if s.feature=='cash':
        for key,expected in independent_cash_oracle(x).items():
            np.testing.assert_allclose(econ[key],expected,atol=1e-6,rtol=0,err_msg='independent cash oracle '+key)
    if s.feature.startswith('weight_'):
        for key,expected in independent_weight_oracle(s,x).items():
            np.testing.assert_allclose(econ[key],expected,atol=1e-6,rtol=0,err_msg='independent weight oracle '+key)
    if s.feature in ('constraints','stateful'):
        from matrix_extra_models import constraints_oracle,stateful_oracle
        oracle=constraints_oracle(x) if s.feature=='constraints' else stateful_oracle(x)
        for key,expected in oracle.items():
            np.testing.assert_allclose(econ[key],expected,atol=1e-6,rtol=0,err_msg='independent event oracle '+key)
    if args.reference:
        expected=np.load(args.reference)
        for key in econ:
            np.testing.assert_allclose(econ[key],expected[key],atol=1e-6,rtol=0,err_msg=key)
    timings=[]; output_timings=[]
    while len(timings)<args.repeats or sum(timings)+sum(output_timings)<args.seconds:
        start=time.perf_counter();result=runner();timings.append(time.perf_counter()-start)
        start=time.perf_counter();econ=economic_dori(result,data) if data else economic_vectorbt(result);output_timings.append(time.perf_counter()-start)
    measured_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if data and native_evidence is not None:
        from matrix_native_evidence import diagnose_route
        native_evidence.update(diagnose_route(runner,s.name))
    if args.profile:
        import cProfile
        profiler=cProfile.Profile();profiler.runcall(runner);profiler.dump_stats(args.profile)
    econ=economic_dori(result,data) if data else economic_vectorbt(result)
    output=Path(args.output); output.parent.mkdir(parents=True,exist_ok=True)
    save_economic(output.with_suffix('.npz'),econ)
    fields=public_fields(result) if data else {}
    versions={k:importlib.metadata.version(k) for k in ('numpy','numba','vectorbt','vectorbt-rust')}
    if data: versions['doribt']=importlib.metadata.version('doribt')
    if data and versions['doribt']!='0.6.0': raise RuntimeError('Expected exact released doribt 0.6.0')
    payload=dict(scenario=dataclasses.asdict(s),engine=args.engine,workload_sha256=x['sha256'],
        bars=len(x['price']),assets=len(x['symbols']),smoke=args.smoke,versions=versions,
        imported_module=getattr(doribt,'__file__',None) if data else vectorbt.__file__,
        comparison_vectorbt_adapter=('python-flexible-order-callback' if os.environ.get('MATRIX_STATEFUL_NUMBA')!='1' else 'numba-rewritten-flexible-order-callback') if s.feature=='stateful' else 'numba-t1-status-state-arrays' if s.feature=='constraints' else 'python-flexible-target-callback' if s.callback and s.feature=='plain' and os.environ.get('MATRIX_TARGET_CALLBACK_MODE')!='rust' else s.vbt,
        common_import_seconds=IMPORT_BASE,engine_import_seconds=imported,generation_seconds=generated,
        preparation_seconds=preparation,first_execution_seconds=first,result_materialization_seconds=materialization,
        warm_seconds=timings,warm_median_seconds=float(np.median(timings)),warm_total_seconds=sum(timings),
        peak_rss_kib=measured_peak_rss_kib,
        warm_output_seconds=output_timings,
        warm_ready_seconds=[a+b for a,b in zip(timings,output_timings)],
        warm_ready_total_seconds=sum(timings)+sum(output_timings),
        warm_ready_median_seconds=float(np.median(np.array(timings)+output_timings)),
        run_info=result.run_info.to_dict() if data else None,
        audit_counts={k:len(getattr(result,k)) for k in ('orders','intents','tax_lots','corporate_events','entitlements')} if data else None,
        process_cold=True,numba_disk_cache=os.environ.get('NUMBA_CACHE_DIR','default cache; may be populated'),
        trade_count=len(econ['fills']),public_fields=fields,
        comparison_scope='cash, holdings, equity, fills' if args.engine=='vbt' else 'all public dataclass fields; provenance and backend classified separately',
        thread_limits={key:os.environ.get(key) for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS','RAYON_NUM_THREADS')},python=sys.version,native_evidence=native_evidence if data else None)
    output.write_text(json.dumps(payload,indent=2,default=str)); print(json.dumps({k:v for k,v in payload.items() if k not in ('public_fields','warm_seconds','warm_output_seconds','warm_ready_seconds','run_info')}),flush=True)
if __name__=='__main__': main()
