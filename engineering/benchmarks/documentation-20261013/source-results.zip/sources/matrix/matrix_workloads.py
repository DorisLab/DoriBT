"""确定性公共 API 场景；没有复制引擎内部实现。"""
from dataclasses import dataclass, asdict
from datetime import date, timedelta
import hashlib, json
import numpy as np

@dataclass(frozen=True)
class Scenario:
    name: str
    minute: bool = False
    dense: bool = False
    callback: bool = False
    feature: str = 'plain'
    assets: int = 100
    days: int = 252
    vbt: str | None = 'rust'

SCENARIOS = [
    Scenario('daily_sparse_targets'),
    Scenario('daily_dense_targets', dense=True),
    Scenario('minute_sparse_targets', minute=True, days=25),
    Scenario('minute_dense_targets', minute=True, dense=True, days=25),
    Scenario('daily_sparse_callback', callback=True),
    Scenario('daily_dense_callback', dense=True, callback=True),
    Scenario('minute_sparse_callback', minute=True, callback=True, days=25),
    Scenario('minute_dense_callback', minute=True, dense=True, callback=True, days=25),
    Scenario('daily_shared_cash', feature='cash', vbt='numba'),
    Scenario('daily_rounded_fees', dense=True, feature='fees', vbt='numba'),
    Scenario('minute_partial_fills', minute=True, feature='partial', days=25, vbt='numba'),
    Scenario('minute_t1_limits_status', minute=True, dense=True, feature='constraints', days=25, vbt=None),
    Scenario('daily_corporate_actions', callback=True, feature='actions', vbt=None),
    Scenario('minute_stateful_orders', minute=True, callback=True, feature='stateful', days=25, vbt=None),
    Scenario('daily_weights_close_once', feature='weight_close_once', vbt='numba'),
    Scenario('daily_weights_close_rebalance', feature='weight_close_rebalance', vbt='numba'),
    Scenario('minute_weights_execution_once', minute=True, days=25, feature='weight_execution_once', vbt='numba'),
    Scenario('minute_weights_execution_rebalance', minute=True, days=25, feature='weight_execution_rebalance', vbt='numba'),
]

def make_inputs(s, smoke=False):
    assets = min(s.assets, 3) if smoke else s.assets
    ndays = min(s.days, 4) if smoke else s.days
    days=[]; day=date(2024,1,2)
    while len(days)<ndays:
        if day.weekday()<5: days.append(day)
        day+=timedelta(days=1)
    bars=ndays*(48 if s.minute else 1)
    i=np.arange(bars)[:,None]; j=np.arange(assets)[None,:]
    price=(1000+5*(i%13)+3*j).astype(np.int64)
    close=price+((i+j)%5-2)
    period=2 if s.dense else (48 if s.minute else 20)
    targets=np.broadcast_to(np.where((i//period)%2==0,300,0),(bars,assets)).copy()
    if s.feature=='fees': targets*=10
    volume=np.full((bars,assets),1_000_000,dtype=np.int64)
    if s.feature=='partial': volume[:]=100
    status=np.zeros((bars,assets),np.int8)
    upper=np.full((bars,assets),999999,np.int64)
    if s.feature=='constraints':
        status[(i[:,0]%19)==1,:]=1
        volume[status==1]=0
        upper[(i[:,0]%17)==1,:]=price[(i[:,0]%17)==1,:]
        close[(i[:,0]%17)==1,:]=price[(i[:,0]%17)==1,:]
    cash=assets*1500 if s.feature=='cash' else 10_000_000
    payload=dict(days=days, price=price, close=close, targets=targets, volume=volume,
                 status=status, upper=upper, cash=cash, symbols=[f'S{a:03}' for a in range(assets)])
    digest=hashlib.sha256(json.dumps({'scenario':asdict(s),'days':list(map(str,days)),'cash':cash},sort_keys=True).encode())
    for key in ('price','close','targets','volume','status','upper'): digest.update(payload[key].tobytes())
    payload['sha256']=digest.hexdigest()
    return payload

def prepare_dori(s, x):
    from doribt import (Backtest, BarExecution, CorporateAction, Costs, Instrument,
                        MarketData, MinuteClock, PositionTargets, RuleBook,
                        RulePeriod, RunConfig, TradingRule, WeightTargets)
    days=x['days']; symbols=x['symbols']
    timeline=MinuteClock.build(days,'5min').timestamps if s.minute else days
    rule=TradingRule(price_tick='.01',buy_minimum=1,buy_step=1,sell_step=1,
                     settlement_days=1 if s.feature=='constraints' else 0,
                     stamp_duty_sell=0,transfer_fee=0)
    rules=RuleBook(tuple(RulePeriod(symbol=y,start=days[0],end=days[-1],rule=rule,
                                  source='独立合成矩阵',version='1') for y in symbols))
    rows=[]
    for i,t in enumerate(timeline):
        for j,y in enumerate(symbols):
            op=x['price'][i,j]/100; cl=x['close'][i,j]/100
            row=dict(symbol=y,status='suspended' if x['status'][i,j] else 'trading',
                     open=op,high=max(op,cl),low=min(op,cl),close=cl,
                     volume=int(x['volume'][i,j]),upper_limit=x['upper'][i,j]/100,lower_limit=.01)
            row.update(dict(timestamp=t,phase='continuous') if s.minute else dict(session=t))
            rows.append(row)
    actions=[]
    if s.feature=='actions':
        for j,y in enumerate(symbols):
            actions.append(CorporateAction(action_id=f'cash-{j}',symbol=y,kind='distribution',
                announced=days[0],record_date=days[1],ex_date=days[2],cash_per_share='.1',
                pay_date=days[3],source='独立合成现金分红'))
    kw=dict(calendar=days,instruments=[Instrument(symbol=y,kind='stock') for y in symbols],
            rules=rules,source='独立合成矩阵',actions=actions)
    data=MarketData.from_minutes(rows,frequency='5min',**kw) if s.minute else MarketData.from_records(rows,**kw)
    target=PositionTargets(sessions=data.timeline,quantities={y:x['targets'][:,j] for j,y in enumerate(symbols)})
    if s.feature.startswith('weight_'):
        weights=np.where(x['targets']>0,(800000//len(symbols))/1e6,0.)
        target=WeightTargets(sessions=data.timeline,weights={y:weights[:,j] for j,y in enumerate(symbols)},
             sizing='execution' if 'execution' in s.feature else 'close',rebalance=s.feature.endswith('rebalance'))
    def wrapper(ctx): target(ctx)
    def stateful(ctx):
        # 真实 Python 回调读取账本、窗口历史并记录输出；每次运行无外部可变状态。
        i=ctx.bar_index
        if i%7==0:
            for y in ctx.symbols:
                held=ctx.account.positions[y].quantity
                history=ctx.history(y,bars=3)
                if held==0 and history[-1]>=history[0]: ctx.order(y,100,valid_for='day')
                elif held>0: ctx.order(y,-held,valid_for='next_bar')
        ctx.record(cash=ctx.account.cash)
    strategy=stateful if s.feature=='stateful' else wrapper if s.callback else target
    costs=Costs(commission='.0003',minimum_commission=5) if s.feature=='fees' else Costs(commission=0,minimum_commission=0)
    bt=Backtest(data,config=RunConfig(initial_cash=x['cash'],costs=costs,
                execution=BarExecution(participation=1)))
    return lambda:bt.run(strategy,backend='numba'),data

def independent_plain_oracle(x):
    """无约束场景使用整数分独立记账；不读任何引擎内部数据。"""
    holdings=np.vstack([np.zeros((1,len(x['symbols'])),dtype=np.int64),x['targets'][:-1]])
    delta=np.diff(np.vstack([np.zeros((1,len(x['symbols'])),dtype=np.int64),holdings]),axis=0)
    cash_cents=x['cash']*100-np.cumsum((delta*x['price']).sum(axis=1))
    equity_cents=cash_cents+(holdings*x['close']).sum(axis=1)
    fills=np.array([(i,j,int(delta[i,j]),x['price'][i,j]/100,0.) for i,j in zip(*np.nonzero(delta))]).reshape(-1,5)
    return dict(cash=cash_cents/100,holdings=holdings,equity=equity_cents/100,fills=fills)

def independent_execution_oracle(s,x):
    """费用/成交量模型：整数分、持续目标、每 bar 每证券至多一次成交。"""
    cash=x['cash']*100; held=np.zeros(len(x['symbols']),np.int64)
    cash_path=[]; equity=[]; positions=[]; fills=[]
    for i in range(len(x['price'])):
        if i:
            for j in range(len(held)):
                difference=int(x['targets'][i-1,j]-held[j])
                qty=min(abs(difference),int(x['volume'][i,j]))
                if not qty: continue
                qty=qty if difference>0 else -qty
                cents=abs(qty)*int(x['price'][i,j])
                fee=max(500,(cents*3+5000)//10000) if s.feature=='fees' else 0
                cash-=qty*int(x['price'][i,j])+fee;held[j]+=qty
                fills.append((i,j,qty,x['price'][i,j]/100,fee/100))
        cash_path.append(cash/100);positions.append(held.copy())
        equity.append((cash+sum(held*x['close'][i]))/100)
    return dict(cash=np.array(cash_path),holdings=np.array(positions),equity=np.array(equity),
                fills=np.array(fills).reshape(-1,5))

def independent_cash_oracle(x):
    """公开规范：收盘按证券顺序冻结买入预算，未完单余款至到期才释放。"""
    cash=int(x['cash']*100); held=np.zeros(len(x['symbols']),np.int64)
    cash_path=[]; equity=[]; positions=[]; fills=[]
    for i in range(len(x['price'])):
        if i:
            requested=x['targets'][i-1]-held
            budgets=np.zeros(len(held),np.int64);free=cash
            for j in range(len(held)):
                budgets[j]=min(free,max(0,int(requested[j]))*int(x['close'][i-1,j]));free-=budgets[j]
            for j in range(len(held)):
                qty=int(requested[j]);px=int(x['price'][i,j])
                if qty>0: qty=min(qty,(int(budgets[j])+free)//px)
                if not qty: continue
                spend=qty*px
                if qty<0: free-=spend
                elif qty==requested[j]: free+=int(budgets[j])-spend
                else: free=max(0,free-max(0,spend-int(budgets[j])))
                cash-=spend;held[j]+=qty;fills.append((i,j,qty,px/100,0.))
        cash_path.append(cash/100);positions.append(held.copy());equity.append((cash+sum(held*x['close'][i]))/100)
    return dict(cash=np.array(cash_path),holdings=np.array(positions),equity=np.array(equity),fills=np.array(fills).reshape(-1,5))

def independent_weight_oracle(s,x):
    cash=int(x['cash']*100); held=np.zeros(len(x['symbols']),np.int64);desired=held.copy()
    cash_path=[];equity=[];positions=[];fills=[];ppm=800000//len(held)
    for i in range(len(x['price'])):
        if i:
            changed=i==1 or np.any(x['targets'][i-1]!=x['targets'][i-2])
            if changed or s.feature.endswith('rebalance'):
                px=x['price'][i] if 'execution' in s.feature else x['close'][i-1]
                value=cash+sum(held*px)
                weights=np.where(x['targets'][i-1]>0,ppm,0)
                desired=(value*weights)//(px*1_000_000)
            for j in range(len(held)):
                qty=int(desired[j]-held[j])
                if qty:
                    cash-=qty*int(x['price'][i,j]);held[j]+=qty
                    fills.append((i,j,qty,x['price'][i,j]/100,0.))
        cash_path.append(cash/100);positions.append(held.copy());equity.append((cash+sum(held*x['close'][i]))/100)
    return dict(cash=np.array(cash_path),holdings=np.array(positions),equity=np.array(equity),fills=np.array(fills).reshape(-1,5))
