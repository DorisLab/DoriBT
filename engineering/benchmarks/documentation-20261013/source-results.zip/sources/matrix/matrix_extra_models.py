"""已冻结场景的独立 T+1 状态模型和真实 Python 策略回调适配。"""
import numpy as np


def constraints_oracle(x):
    held=np.zeros(len(x['symbols']),np.int64);sellable=held.copy();cash=int(x['cash']*100)
    cash_path=[];equity=[];positions=[];fills=[]
    for i in range(len(x['price'])):
        if i%48==0: sellable=held.copy()
        if i:
            for j in range(len(held)):
                difference=int(x['targets'][i-1,j]-held[j])
                if x['status'][i,j] or x['volume'][i,j]==0: continue
                if difference>0 and x['price'][i,j]>=x['upper'][i,j]: continue
                qty=min(abs(difference),int(x['volume'][i,j]))
                if difference<0: qty=-min(qty,int(sellable[j]));sellable[j]+=qty
                if qty:
                    held[j]+=qty;cash-=qty*int(x['price'][i,j]);fills.append((i,j,qty,x['price'][i,j]/100,0.))
        cash_path.append(cash/100);positions.append(held.copy());equity.append((cash+sum(held*x['close'][i]))/100)
    return dict(cash=np.array(cash_path),holdings=np.array(positions),equity=np.array(equity),fills=np.array(fills).reshape(-1,5))


def stateful_oracle(x):
    held=np.zeros(len(x['symbols']),np.int64);cash=int(x['cash']*100)
    cash_path=[];equity=[];positions=[];fills=[]
    for i in range(len(x['price'])):
        if i and (i-1)%7==0:
            previous=i-1
            for j in range(len(held)):
                qty=-held[j] if held[j] else 100 if x['close'][previous,j]>=x['close'][max(0,previous-2),j] else 0
                if qty:
                    held[j]+=qty;cash-=qty*int(x['price'][i,j]);fills.append((i,j,qty,x['price'][i,j]/100,0.))
        cash_path.append(cash/100);positions.append(held.copy());equity.append((cash+sum(held*x['close'][i]))/100)
    return dict(cash=np.array(cash_path),holdings=np.array(positions),equity=np.array(equity),fills=np.array(fills).reshape(-1,5))


def prepare_constraints(x,common):
    import vectorbt as vbt
    from numba import njit
    @njit
    def unlock(c,sellable):
        if c.i%48==0:
            for j in range(c.from_col,c.to_col): sellable[j]=int(c.last_position[j])
        return (sellable,)
    @njit
    def order(c,sellable,targets,price,volume,status,upper):
        if c.i==0 or status[c.i,c.col] or volume[c.i,c.col]==0: return vbt.portfolio.nb.order_nb(size=np.nan)
        difference=targets[c.i-1,c.col]-c.position_now
        if difference>0 and price[c.i,c.col]>=upper[c.i,c.col]: return vbt.portfolio.nb.order_nb(size=np.nan)
        qty=min(abs(difference),volume[c.i,c.col])
        if difference<0: qty=-min(qty,sellable[c.col]);sellable[c.col]+=int(qty)
        return vbt.portfolio.nb.order_nb(size=qty if qty else np.nan,price=price[c.i,c.col]/100,direction=0,allow_partial=False)
    def run():
        return vbt.Portfolio.from_order_func(x['close']/100,order,x['targets'],x['price'],x['volume'],x['status'],x['upper'],
            pre_segment_func_nb=unlock,pre_segment_args=(np.zeros(len(x['symbols']),np.int64),),**common)
    return run


def prepare_stateful(x,common,use_numba=False):
    import vectorbt as vbt
    def order(c,close,price):
        previous=c.i-1
        if previous<0 or previous%7 or c.call_idx>=c.group_len: return -1,vbt.portfolio.nb.order_nb(size=np.nan)
        col=c.from_col+c.call_idx
        history=close[max(0,previous-2):previous+1,col].copy()
        held=c.last_position[col]
        quantity=-held if held>0 else 100 if history[-1]>=history[0] else 0
        return col,vbt.portfolio.nb.order_nb(size=quantity if quantity else np.nan,price=price[c.i,col],direction=0,allow_partial=False)
    if use_numba:
        from numba import njit
        order=njit(order)
    def run():
        return vbt.Portfolio.from_order_func(x['close']/100,order,x['close']/100,x['price']/100,use_numba=use_numba,flexible=True,**common)
    return run


def prepare_target_callback(x,common):
    """与Dori包装回调同样使用Python逐列寻找目标变化；稀疏flexible订单接口。"""
    import vectorbt as vbt
    columns=[tuple(x['targets'][:,j].tolist()) for j in range(len(x['symbols']))]
    prices=x['price']/100; close=x['close']/100
    def run():
        pending=[]
        def callback(c):
            previous=c.i-1
            if previous<0: return -1,vbt.portfolio.nb.order_nb(size=np.nan)
            if c.call_idx==0:
                pending.clear()
                for j,values in enumerate(columns):
                    if previous==0 or values[previous]!=values[previous-1]: pending.append((j,values[previous]))
            if c.call_idx>=len(pending): return -1,vbt.portfolio.nb.order_nb(size=np.nan)
            j,target=pending[c.call_idx];quantity=target-c.last_position[j]
            return j,vbt.portfolio.nb.order_nb(size=quantity if quantity else np.nan,price=prices[c.i,j],direction=0,allow_partial=False)
        return vbt.Portfolio.from_order_func(close,callback,use_numba=False,flexible=True,**common)
    return run
