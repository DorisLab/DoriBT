"""Same 252k-cell portfolio, >=10 seconds accumulated measured warm execution."""
import argparse,json,resource,time
from pathlib import Path
import numpy as np
from benchmark import dataset,prepare,reference,verify
p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--output',required=True);a=p.parse_args()
d,o,c,t=dataset(2520,100);expected=reference(o,c,t,1e7)
start=time.perf_counter();run=prepare(a.engine,d,o,c,t,1e7);prepared=time.perf_counter()-start
start=time.perf_counter();out=run();first=time.perf_counter()-start;verify(out,expected)
times=[];total=0
while total<10 or len(times)<3:
 start=time.perf_counter();out=run();elapsed=time.perf_counter()-start
 times.append(elapsed);total+=elapsed
 verify(out,expected)
r=dict(engine=a.engine,bars=2520,assets=100,measured_repetitions=len(times),accumulated_execution_seconds=total,warm_seconds=times,warm_median_seconds=float(np.median(times)),warm_min_seconds=min(times),warm_max_seconds=max(times),asset_bars_per_second=252000/(total/len(times)),preparation_seconds=prepared,first_execution_seconds=first,trade_count=len(out['fills']),verified=True,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
Path(a.output).write_text(json.dumps(r,indent=2));print(json.dumps(r))
