"""Independent public-API benchmark. Synthetic data, no investing claims."""
import argparse, hashlib, importlib.metadata as md, json, os, platform, resource, sys, time
from pathlib import Path
import numpy as np
import pandas as pd

SEED=7301

def dataset(bars, assets, fast=5):
    import exchange_calendars as xc
    dates=xc.get_calendar('XNYS', start='2015-01-01',end='2030-12-31').sessions
    dates=dates[dates>=pd.Timestamp('2016-01-04')][:bars]
    rng=np.random.default_rng(SEED)
    close=np.round(20*np.exp(np.cumsum(rng.normal(0,.008,(bars,assets)),axis=0)),2)
    op=np.round(np.vstack([np.full((1,assets),20.),close[:-1]])*(1+rng.normal(0,.003,(bars,assets))),2)
    frame=pd.DataFrame(close)
    targets=np.where((frame.rolling(fast).mean()>frame.rolling(20).mean()).to_numpy(),100,0)
    return dates,op,close,targets

def reference(op,close,target,cash0):
    held=np.vstack([np.zeros((1,op.shape[1]),dtype=int),target[:-1]])
    delta=np.diff(np.vstack([np.zeros((1,op.shape[1]),dtype=int),held]),axis=0)
    # Integer cents oracle; no engine code is imported here.
    cashc=np.int64(round(cash0*100))-np.cumsum((delta*np.rint(op*100).astype(np.int64)).sum(axis=1))
    eqc=cashc+(held*np.rint(close*100).astype(np.int64)).sum(axis=1)
    fills=[(i,j,int(delta[i,j]),float(op[i,j]),0.) for i,j in zip(*np.nonzero(delta))]
    return dict(cash=cashc/100,holdings=held,equity=eqc/100,fills=fills)

def prepare(engine,dates,op,close,target,cash0):
    if engine.startswith('doribt'):
        from doribt import Backtest,MarketData,Instrument,RuleBook,RulePeriod,TradingRule,Costs,RunConfig,PositionTargets,BarExecution
        days=dates.strftime('%Y-%m-%d').tolist(); symbols=[f'S{j:03}' for j in range(op.shape[1])]
        rule=TradingRule(price_tick=.01,buy_minimum=1,buy_step=1,sell_step=1,settlement_days=0,stamp_duty_sell=0,transfer_fee=0)
        rules=RuleBook(tuple(RulePeriod(symbol=s,start=days[0],end=days[-1],rule=rule,source='Synthetic frictionless benchmark',version='1') for s in symbols))
        records=[dict(session=d,symbol=s,status='trading',open=float(op[i,j]),close=float(close[i,j]),high=float(max(op[i,j],close[i,j])),low=float(min(op[i,j],close[i,j])),volume=1000000000,upper_limit=None,lower_limit=None) for i,d in enumerate(days) for j,s in enumerate(symbols)]
        data=MarketData.from_records(records,calendar=days,instruments=[Instrument(symbol=s,kind='stock') for s in symbols],rules=rules,source='Synthetic seeded benchmark')
        strat=PositionTargets(sessions=data.timeline,quantities={s:target[:,j] for j,s in enumerate(symbols)})
        if engine.endswith('-callback'):
            scheduled=strat
            def callback(ctx): scheduled(ctx)
            strat=callback
        bt=Backtest(data,config=RunConfig(initial_cash=cash0,costs=Costs(commission=0,minimum_commission=0),execution=BarExecution(participation=1)))
        times={d:i for i,d in enumerate(data.timeline)}; syms={s:j for j,s in enumerate(symbols)}
        def run(selected=None):
            r=bt.run(strat if selected is None else selected,backend=engine.split('-')[1])
            return dict(cash=r.cash,holdings=r.holdings,equity=r.equity,fills=[(times[f.session],syms[f.symbol],f.quantity,f.price_units/10000,f.commission_units/10000) for f in r.fills])
        run.prepare_target=lambda matrix: PositionTargets(sessions=data.timeline,quantities={s:matrix[:,j] for j,s in enumerate(symbols)})
        return run
    if engine=='backtrader':
        import backtrader as bt
        frames=[pd.DataFrame(dict(open=op[:,j],high=np.maximum(op[:,j],close[:,j]),low=np.minimum(op[:,j],close[:,j]),close=close[:,j],volume=1e9),index=dates) for j in range(op.shape[1])]
        class Strategy(bt.Strategy):
            def __init__(self): self.cash=[]; self.equity=[]; self.holdings=[]; self.fills=[]
            def next(self):
                i=len(self)-1
                self.cash.append(self.broker.getcash());self.equity.append(self.broker.getvalue());self.holdings.append([self.getposition(d).size for d in self.datas])
                for j,d in enumerate(self.datas):
                    if i==0 or target[i,j]!=target[i-1,j]: self.order_target_size(data=d,target=int(target[i,j]))
            def notify_order(self,order):
                if order.status==order.Completed:
                    self.fills.append((len(self)-1,next(j for j,d in enumerate(self.datas) if d is order.data),order.executed.size,order.executed.price,order.executed.comm))
        def run():
            cerebro=bt.Cerebro(stdstats=False);cerebro.broker.setcash(cash0);cerebro.broker.setcommission(commission=0)
            for f in frames: cerebro.adddata(bt.feeds.PandasData(dataname=f))
            cerebro.addstrategy(Strategy);r=cerebro.run()[0]
            return dict(cash=np.asarray(r.cash),holdings=np.asarray(r.holdings),equity=np.asarray(r.equity),fills=r.fills)
        return run
    if engine.startswith('vectorbt'):
        import vectorbt as vbt
        size=np.full(target.shape,np.nan);size[1:]=np.where(np.vstack([np.ones((1,target.shape[1]),bool),np.diff(target[:-1],axis=0)!=0]),target[:-1],np.nan)
        def run():
            r=vbt.Portfolio.from_orders(close,size=size,size_type='targetamount',price=op,init_cash=cash0,cash_sharing=True,group_by=True,fees=0,slippage=0,direction='longonly',engine=engine.split('-')[1],freq='1D')
            fills=[(int(f['idx']),int(f['col']),float(f['size'])*(1 if f['side']==0 else -1),float(f['price']),float(f['fees'])) for f in r.orders.records_arr]
            return dict(cash=np.asarray(r.cash()).reshape(-1),holdings=np.asarray(r.assets()),equity=np.asarray(r.value()).reshape(-1),fills=fills)
        return run
    if engine=='zipline':
        from zipline_adapter import prepare as zp
        return zp(dates,op,close,target,cash0)
    raise ValueError(engine)

def verify(actual,expected):
    errors={}
    for key in ('cash','equity','holdings'):
        a=np.asarray(actual[key]);e=expected[key]
        if a.shape!=e.shape: raise AssertionError(f'{key} shape {a.shape} != {e.shape}')
        errors[key]=float(np.max(np.abs(a-e)))
        np.testing.assert_allclose(a,e,rtol=0,atol=1e-6 if key!='holdings' else 0,err_msg=key)
    a=sorted(actual['fills']);e=sorted(expected['fills'])
    if len(a)!=len(e): raise AssertionError(f'fills {len(a)} != {len(e)}; first actual {a[:5]} expected {e[:5]}')
    np.testing.assert_allclose(a,e,rtol=0,atol=1e-8)
    return errors

def main():
    p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--bars',type=int,default=252);p.add_argument('--assets',type=int,default=1);p.add_argument('--repeats',type=int,default=3);p.add_argument('--output',required=True);p.add_argument('--batch',type=int,default=1);p.add_argument('--min-seconds',type=float,default=10);args=p.parse_args()
    start=time.perf_counter();dates,op,close,target=dataset(args.bars,args.assets);generated=time.perf_counter()-start
    cash0=1e7;expected=reference(op,close,target,cash0)
    start=time.perf_counter();run=prepare(args.engine,dates,op,close,target,cash0);prepared=time.perf_counter()-start
    start=time.perf_counter();actual=run();first=time.perf_counter()-start;errors=verify(actual,expected)
    times=[]
    while len(times)<args.repeats or sum(times)<args.min_seconds:
        start=time.perf_counter();actual=run();times.append(time.perf_counter()-start);verify(actual,expected)
    versions={n:md.version(n) for n in ('numpy','pandas')}
    for n in ('doribt','numba','backtrader','vectorbt','vectorbt-rust','zipline-reloaded'):
        try: versions[n]=md.version(n)
        except md.PackageNotFoundError: pass
    payload=dict(engine=args.engine,bars=args.bars,assets=args.assets,seed=SEED,python=sys.version,versions=versions,dataset_sha256=hashlib.sha256(op.tobytes()+close.tobytes()+target.tobytes()).hexdigest(),generation_signal_seconds=generated,preparation_seconds=prepared,first_execution_seconds=first,warm_seconds=times,measured_repetitions=len(times),accumulated_execution_seconds=sum(times),warm_median_seconds=float(np.median(times)),peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,trade_count=len(actual['fills']),final_equity=float(actual['equity'][-1]),max_absolute_errors=errors)
    Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(payload),flush=True)
if __name__=='__main__':main()
