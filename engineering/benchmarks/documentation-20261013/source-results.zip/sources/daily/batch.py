"""Ten independent parameter accounts; native vectorbt column batching vs sequential APIs."""
import argparse,json,time,resource
from pathlib import Path
import numpy as np
from benchmark import dataset,prepare,reference,verify
p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--output',required=True);args=p.parse_args()
start=time.perf_counter();cases=[dataset(2520,1,fast=f) for f in range(2,12)];cash0=1e7
expected=[reference(o,c,t,cash0) for d,o,c,t in cases]
if args.engine.startswith('vectorbt'):
 import vectorbt as vbt
 closes=np.column_stack([c[:,0] for d,o,c,t in cases]);opens=np.column_stack([o[:,0] for d,o,c,t in cases]);targets=np.column_stack([t[:,0] for d,o,c,t in cases])
 size=np.full(targets.shape,np.nan);size[1:]=np.where(np.vstack([np.ones((1,10),bool),np.diff(targets[:-1],axis=0)!=0]),targets[:-1],np.nan)
 def run():
  r=vbt.Portfolio.from_orders(closes,size=size,size_type='targetamount',price=opens,init_cash=cash0,cash_sharing=False,group_by=False,fees=0,slippage=0,direction='longonly',engine=args.engine.split('-')[1],freq='1D')
  cash=np.asarray(r.cash());hold=np.asarray(r.assets());equity=np.asarray(r.value());records=r.orders.records_arr
  return [dict(cash=cash[:,j],holdings=hold[:,j:j+1],equity=equity[:,j],fills=[(int(f['idx']),0,float(f['size'])*(1 if f['side']==0 else -1),float(f['price']),float(f['fees'])) for f in records if f['col']==j]) for j in range(10)]
else:
 runs=[prepare(args.engine,d,o,c,t,cash0) for d,o,c,t in cases]
 def run():return [f() for f in runs]
prepared=time.perf_counter()-start
start=time.perf_counter();actual=run();first=time.perf_counter()-start
for a,e in zip(actual,expected):verify(a,e)
times=[]
while len(times)<3 or sum(times)<10:
 start=time.perf_counter();actual=run();times.append(time.perf_counter()-start)
 for a,e in zip(actual,expected):verify(a,e)
r=dict(engine=args.engine,bars=2520,accounts=10,assets_per_account=1,fast_windows=list(range(2,12)),slow_window=20,preparation_including_generation_seconds=prepared,first_execution_seconds=first,warm_seconds=times,measured_repetitions=len(times),accumulated_execution_seconds=sum(times),warm_median_seconds=float(np.median(times)),trade_counts=[len(a['fills']) for a in actual],final_equities=[float(a['equity'][-1]) for a in actual],verified=True,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
Path(args.output).write_text(json.dumps(r,indent=2));print(json.dumps(r))
