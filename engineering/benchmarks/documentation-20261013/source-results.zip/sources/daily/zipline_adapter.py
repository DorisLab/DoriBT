"""Zipline-reloaded adapter for the common next-session-open benchmark.

Preparation builds an in-memory session-bar reader and Zipline's real asset
metadata database. Runs use the unmodified TradingAlgorithm, DataPortal,
SimulationBlotter, commissions, ledger, and default performance metrics.

Zipline's normal daily fill price is the close. OpenPriceSlippage is the
supported SlippageModel extension point and changes that price to the current
session's open, fills the entire remainder, and charges no slippage. Orders
submitted in handle_data still wait until the next session. Thus a fill is
processed/timestamped at the next daily event, at that session's OPEN price;
this is a daily next-open execution model, not an intraday engine benchmark.

Sources:
https://zipline.ml4trading.io/api-reference.html#zipline.finance.slippage.SlippageModel
https://zipline.ml4trading.io/_modules/zipline/utils/run_algo.html
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def prepare(dates, opens, closes, targets, initial_cash):
    """Return a repeatable run() with full native Zipline ledger results.

    Input arrays have shape (session_count, symbol_count). targets are integer
    shares decided at each close; only changes generate target orders.
    Imports, reader/asset preparation, and calendar setup happen here, outside
    the timed run. Each run creates a fresh DataPortal and algorithm, performs
    all engine work, and extracts the native daily result into common arrays.
    """
    import sqlalchemy as sa
    from zipline.algorithm import TradingAlgorithm
    from zipline.assets import AssetFinder
    from zipline.assets.asset_writer import AssetDBWriter
    from zipline.data.bar_reader import NoDataOnDate
    from zipline.data.data_portal import DataPortal
    from zipline.data.session_bars import SessionBarReader
    from zipline.finance.commission import PerShare
    from zipline.finance.slippage import SlippageModel
    from zipline.finance.trading import SimulationParameters
    from zipline.utils.calendar_utils import get_calendar

    dates = pd.DatetimeIndex(dates).tz_localize(None).normalize()
    opens = np.asarray(opens, dtype=np.float64)
    closes = np.asarray(closes, dtype=np.float64)
    raw_targets = np.asarray(targets)
    targets = np.asarray(targets, dtype=np.int64)
    if opens.ndim != 2 or opens.shape != closes.shape or opens.shape != targets.shape:
        raise ValueError("opens, closes, targets must have the same two-dimensional shape")
    if len(dates) != len(opens) or len(dates) < 1 or opens.shape[1] < 1:
        raise ValueError("dates must match nonempty input arrays")
    if not np.array_equal(raw_targets, targets):
        raise ValueError("targets must be integer share counts")
    if not (np.isfinite(opens).all() and np.isfinite(closes).all()
            and (opens > 0).all() and (closes > 0).all()):
        raise ValueError("this benchmark reader requires finite positive OHLC prices")
    if not dates.is_monotonic_increasing or not dates.is_unique:
        raise ValueError("dates must be unique increasing XNYS sessions")
    nrows, nassets = opens.shape
    calendar = get_calendar("XNYS", start=dates[0] - pd.Timedelta(days=370),
                            end=dates[-1] + pd.Timedelta(days=370))
    if not dates.equals(calendar.sessions_in_range(dates[0], dates[-1])):
        raise ValueError("dates must be a contiguous sequence of real XNYS sessions")

    class ArraySessionReader(SessionBarReader):
        """Data backend only; execution/accounting stay inside Zipline."""
        def __init__(self):
            self._calendar = calendar
            self._sessions = dates
            self._row = {dt: i for i, dt in enumerate(dates)}
            self._fields = {"open": opens, "close": closes,
                            "high": np.maximum(opens, closes),
                            "low": np.minimum(opens, closes),
                            "volume": np.full(opens.shape, 1_000_000_000, dtype=np.uint32)}

        @property
        def sessions(self):
            return self._sessions

        @property
        def trading_calendar(self):
            return self._calendar

        @property
        def first_trading_day(self):
            return self._sessions[0]

        @property
        def last_available_dt(self):
            return self._sessions[-1]

        def get_value(self, sid, dt, field):
            dt = pd.Timestamp(dt).tz_localize(None).normalize()
            try:
                row = self._row[dt]
            except KeyError:
                raise NoDataOnDate(dt) from None
            return self._fields[field][row, int(sid)]

        def get_last_traded_dt(self, asset, dt):
            dt = pd.Timestamp(dt).tz_localize(None).normalize()
            idx = self._sessions.searchsorted(dt, side="right") - 1
            return pd.NaT if idx < 0 else self._sessions[idx]

        def load_raw_arrays(self, columns, start_date, end_date, assets):
            start = self._sessions.get_loc(pd.Timestamp(start_date).tz_localize(None))
            end = self._sessions.get_loc(pd.Timestamp(end_date).tz_localize(None)) + 1
            sids = np.asarray([int(asset) for asset in assets], dtype=np.int64)
            return [self._fields[field][start:end, :][:, sids] for field in columns]

    class OpenPriceSlippage(SlippageModel):
        def process_order(self, data, order):
            return float(data.current(order.asset, "open")), order.open_amount

    reader = ArraySessionReader()
    engine = sa.create_engine("sqlite:///:memory:")
    metadata = pd.DataFrame({
        "symbol": [f"BENCH{i:05d}" for i in range(nassets)],
        "asset_name": [f"Benchmark equity {i}" for i in range(nassets)],
        "start_date": dates[0],
        # Avoid Zipline's delisting liquidation inside the test interval.
        "end_date": dates[-1] + pd.Timedelta(days=365),
        "auto_close_date": dates[-1] + pd.Timedelta(days=366),
        "exchange": "XNYS",
    }, index=pd.Index(np.arange(nassets), name="sid"))
    exchanges = pd.DataFrame({"exchange": ["XNYS"], "canonical_name": ["XNYS"],
                              "country_code": ["US"]})
    AssetDBWriter(engine).write(equities=metadata, exchanges=exchanges)
    asset_finder = AssetFinder(engine)
    assets = asset_finder.retrieve_all(range(nassets))
    benchmark_returns = pd.Series(0.0, index=dates)

    def run():
        def initialize(context):
            context.set_slippage(us_equities=OpenPriceSlippage())
            context.set_commission(us_equities=PerShare(cost=0.0, min_trade_cost=0.0))
            context._benchmark_row = 0
            context._benchmark_previous_targets = np.zeros(nassets, dtype=np.int64)

        def handle_data(context, data):
            row = context._benchmark_row
            # Only this close's supplied target is consulted. Open-fill prices
            # are selected separately by the engine at the next daily event.
            desired = targets[row]
            changed = np.flatnonzero(desired != context._benchmark_previous_targets)
            for sid in changed:
                context.order_target(assets[sid], int(desired[sid]))
            context._benchmark_previous_targets = desired.copy()
            context._benchmark_row += 1

        portal = DataPortal(asset_finder, calendar, dates[0],
                            equity_daily_reader=reader,
                            last_available_session=dates[-1])
        algorithm = TradingAlgorithm(
            sim_params=SimulationParameters(dates[0], dates[-1], calendar,
                                            capital_base=float(initial_cash),
                                            data_frequency="daily"),
            data_portal=portal,
            trading_calendar=calendar,
            initialize=initialize,
            handle_data=handle_data,
            benchmark_returns=benchmark_returns,
        )
        performance = algorithm.run()
        result_dates = pd.DatetimeIndex(performance.index).tz_localize(None).normalize()
        if not result_dates.equals(dates):
            raise AssertionError("Zipline emitted dates different from the supplied sessions")
        holdings = np.zeros((nrows, nassets), dtype=np.float64)
        fills = []
        for row, (positions, transactions) in enumerate(zip(performance["positions"],
                                                           performance["transactions"])):
            for position in positions:
                holdings[row, int(position["sid"])] = position["amount"]
            for transaction in transactions:
                fills.append((row, int(transaction["sid"]), int(transaction["amount"]),
                              float(transaction["price"]),
                              float(transaction.get("commission") or 0.0)))
        return {
            "cash": performance["ending_cash"].to_numpy(dtype=np.float64),
            "holdings": holdings,
            "equity": performance["portfolio_value"].to_numpy(dtype=np.float64),
            "fills": fills,
        }

    run.adapter_notes = (
        "Actual Zipline TradingAlgorithm/DataPortal/SimulationBlotter/ledger; "
        "in-memory session reader; supported custom SlippageModel fills full "
        "market orders at next session open; zero commission; default metrics; "
        "native daily event timestamp is session close even for open-priced fills."
    )
    # Keep metadata resources alive for all prepared repeated runs.
    run._asset_engine = engine
    return run
