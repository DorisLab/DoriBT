"""Genuinely scaled 100-configuration x 100-asset shared-portfolio SMA sweep."""
import argparse,hashlib,json,resource,time,sys
from importlib.metadata import version,PackageNotFoundError
from pathlib import Path
import numpy as np
import pandas as pd
from benchmark import dataset,prepare,reference,verify
p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--output',required=True);p.add_argument('--count',type=int,default=100);a=p.parse_args()
start=time.perf_counter();dates,op,close,_=dataset(2520,100);frame=pd.DataFrame(close)
pairs=[(f,s) for s in range(20,30) for f in range(2,12)][:a.count]
targets=[np.where((frame.rolling(f).mean()>frame.rolling(s).mean()).to_numpy(),100,0) for f,s in pairs]
expected=[reference(op,close,t,1e7) for t in targets];generated=time.perf_counter()-start
start=time.perf_counter()
if a.engine.endswith('-callback'): raise ValueError('Heavy sweep supports precomputed DoriBT only')
if a.engine.startswith('doribt'):
 runner=prepare(a.engine,dates,op,close,targets[0],1e7)
 strategies=[runner.prepare_target(t) for t in targets]
 def run():return [runner(s) for s in strategies]
 def warm():return runner(strategies[0])
elif a.engine.startswith('vectorbt'):
 import vectorbt as vbt
 # Ten independent shared-cash portfolios per native chunk, bounded memory.
 chunks=[]
 for k in range(0,len(targets),10):
  block=np.concatenate(targets[k:k+10],axis=1);n=block.shape[1]//100
  sizes=np.full(block.shape,np.nan);sizes[1:]=np.where(np.vstack([np.ones((1,block.shape[1]),bool),np.diff(block[:-1],axis=0)!=0]),block[:-1],np.nan)
  chunks.append((np.tile(close,(1,n)),np.tile(op,(1,n)),sizes,np.repeat(np.arange(n),100)))
 def one(chunk):
  c,o,s,groups=chunk;n=len(np.unique(groups))
  r=vbt.Portfolio.from_orders(c,size=s,size_type='targetamount',price=o,init_cash=1e7,cash_sharing=True,group_by=groups,fees=0,slippage=0,direction='longonly',engine=a.engine.split('-')[1],freq='1D')
  cash=np.asarray(r.cash());equity=np.asarray(r.value());hold=np.asarray(r.assets());fills=[[] for _ in range(n)]
  for f in r.orders.records_arr:
   j=int(f['col']);fills[j//100].append((int(f['idx']),j%100,float(f['size'])*(1 if f['side']==0 else -1),float(f['price']),float(f['fees'])))
  return [dict(cash=cash[:,j],equity=equity[:,j],holdings=hold[:,j*100:(j+1)*100],fills=fills[j]) for j in range(n)]
 def run():return [r for chunk in chunks for r in one(chunk)]
 def warm():return one(chunks[0])[0]
else:
 raise ValueError('Use measured single-portfolio costs to report slower full-sweep budget limits; no invented timeout')
prepared=time.perf_counter()-start
start=time.perf_counter();first=warm();warmup=time.perf_counter()-start;verify(first,expected[0]);del first
start=time.perf_counter();actual=run();elapsed=time.perf_counter()-start
assert len(actual)==len(expected), 'Portfolio count mismatch'
errors=[verify(x,e) for x,e in zip(actual,expected)]
r=dict(engine=a.engine,bars=2520,assets_per_portfolio=100,independent_shared_cash_portfolios=len(pairs),asset_bar_evaluations=2520*100*len(pairs),parameter_pairs=pairs,execution_seconds=elapsed,measured_repetitions=1,generation_signals_reference_seconds=generated,preparation_seconds=prepared,warmup_execution_seconds=warmup,trade_counts=[len(x['fills']) for x in actual],total_fills=sum(len(x['fills']) for x in actual),final_equities=[float(x['equity'][-1]) for x in actual],max_absolute_errors={k:max(e[k] for e in errors) for k in errors[0]},peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,verified=True)
r['python']=sys.version
r['market_sha256']=hashlib.sha256(op.tobytes()+close.tobytes()).hexdigest()
r['targets_sha256']=hashlib.sha256(b''.join(t.tobytes() for t in targets)).hexdigest()
r['versions']={}
for name in ('numpy','pandas','doribt','numba','vectorbt','vectorbt-rust'):
 try:r['versions'][name]=version(name)
 except PackageNotFoundError:pass
r['peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
Path(a.output).write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
